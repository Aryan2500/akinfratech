


<?php $__env->startSection('page_css'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('assets/bundles/dataTables.min.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('main_section'); ?>
    <div class="row">
        <?php echo $__env->make('partials.alerts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div class="card mb-4">
            <div class="card-header">
                <h6 class="card-title mb-0">Site list</h6>
                <a type="button" href="<?php echo e(route('site.create')); ?>" class="btn btn-outline-primary float-end ">Create site</a>
            </div>
            <div class="card-body">
                <table class="my_data_table table display dataTable table-hover">
                    <thead>
                        <tr>
                            <th>Name</th>
                            <th>Address</th>
                            <th>Site Head</th>
                            <th>Investors</th>
                            <th>Total size</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $sites; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $site): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($site->name); ?></td>
                                <td><?php echo e($site->address); ?></td>

                                <td>
                                    <?php if($site->head): ?>
                                        <?php echo e($site->head ? $site->head->name : ''); ?> <br>
                                        <?php echo e($site->head ? $site->head->email : ''); ?> <br>
                                        <?php echo e($site->head ? $site->head->phone : ''); ?>

                                    <?php else: ?>
                                        <?php echo e('N/A'); ?>

                                    <?php endif; ?>

                                </td>
                                <td>
                                    <?php if(count($site->investors) > 0): ?>
                                        <ul>
                                            <?php $__currentLoopData = $site->investors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $investor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <li><?php echo e($investor->name); ?></li>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </ul>
                                    <?php else: ?>
                                        <?php echo e('N/A'); ?>

                                    <?php endif; ?>
                                </td>
                                <td><?php echo e($site->total_size); ?></td>
                                <td>
                                    <button class="btn btn-primary">Edit</button>

                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
    <script src="<?php echo e(asset('assets/bundles/dataTables.bundle.js')); ?>"></script>
    <script>
        $(document).ready(function() {
            $('.my_data_table').addClass('nowrap').dataTable({
                responsive: true,
            });
        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layout.' . $layoutfor, \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Aryan\Desktop\realstate\realState\resources\views/pages/admin/site/list.blade.php ENDPATH**/ ?>