<div>
    <input type="hidden" name="id" value="<?php echo e($ptype ? $ptype->id : ''); ?>">
    <?php echo csrf_field(); ?>
    <div class="row">
        <div class="col-6">
            <span class="float-label mt-2">
                <input type="text" class="form-control form-control-lg" id="TextInput" name="name" placeholder="Name"
                    value="<?php echo e($ptype ? $ptype->name : ''); ?>" required>
                <label class="form-label" for="TextInput">Name</label>
            </span>
        </div>

    </div>

    <div class="col-2">
        <button type="submit" class=" btn btn-primary">Submit</button>
    </div>
</div>
<?php /**PATH C:\Users\Aryan\Desktop\realstate\realState\resources\views/pages/admin/plottype/form.blade.php ENDPATH**/ ?>