<div class="modal fade" id="farmerModal" tabindex="-1" aria-labelledby="exampleModalXlLabel" style="display: none;"
    aria-hidden="true">
    <div class="modal-dialog modal-xl">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title h4" id="exampleModalXlLabel">Farmers List</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <div class="card mb-4">
                    <div class="card-header">
                        <h6 class="card-title mb-0">Farmer list</h6>
                        <a type="button" href="<?php echo e(route('farmer.create')); ?>"
                            class="btn btn-outline-primary float-end ">Create new</a>
                    </div>
                    <div class="card-body">
                        <table class="my_data_table table display dataTable table-hover">
                            <thead>
                                <tr>
                                    <th>Site</th>
                                    <th>Farmer Name</th>
                                    <th>State</th>
                                    <th>City</th>
                                    <th>Phone Number</th>
                                    <th>Address</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = FarmerHelper::getAllFarmers(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $f): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($f->sites->first()->name); ?></td>
                                        <td><?php echo e($f->name); ?></td>
                                        <td><?php echo e($f->city->state->name); ?></td>
                                        <td><?php echo e($f->city->name); ?></td>
                                        <td><?php echo e($f->phone); ?></td>
                                        <td><?php echo e($f->address); ?></td>
                                        <td>
                                            <button class="btn btn-primary">Edit</button>
                                            <button class="btn btn-danger">Lock</button>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php /**PATH C:\Users\Aryan\Desktop\realstate\realState\resources\views/pages/admin/dashboard/farmer-list-modal.blade.php ENDPATH**/ ?>