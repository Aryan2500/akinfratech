

<?php $__env->startSection('page_css'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('assets/bundles/dataTables.min.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('main_section'); ?>
    <div class="row">
        <?php echo $__env->make('partials.alerts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div class="card mb-4">
            <div class="card-header">
                <h6 class="card-title mb-0">Plot type list</h6>
                <a type="button" href="<?php echo e(route('plottype.create')); ?>" class="btn btn-outline-primary float-end ">Create Plot
                    type</a>
            </div>
            <div class="card-body">
                <table class="my_data_table table display dataTable table-hover" style="text-align: center">
                    <thead>
                        <tr>
                            <th>Name</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $plottypes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($type->name); ?></td>

                                <td>
                                    <a class="btn btn-primary" href="<?php echo e(route('plottype.edit', $type->id)); ?>">Edit</a>
                                    <button class="btn btn-danger">Lock</button>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
    <script src="<?php echo e(asset('assets/bundles/dataTables.bundle.js')); ?>"></script>
    <script>
        $(document).ready(function() {
            $('.my_data_table').addClass('nowrap').dataTable({
                responsive: true,
            });
        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layout.' . $layoutfor, \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Aryan\Desktop\realstate\realState\resources\views/pages/admin/plottype/list.blade.php ENDPATH**/ ?>