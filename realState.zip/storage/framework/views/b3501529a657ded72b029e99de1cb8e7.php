


<?php $__env->startSection('page_css'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('assets/bundles/dataTables.min.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('main_section'); ?>
    <div class="row">
        <?php echo $__env->make('partials.alerts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div class="card mb-4">
            <div class="card-header">
                <h6 class="card-title mb-0">Land list</h6>
                <a type="button" href="<?php echo e(route('land.create')); ?>" class="btn btn-outline-primary float-end ">Create land</a>
            </div>
            <div class="card-body">
                <table class="my_data_table table display dataTable table-hover">
                    <thead>
                        <tr>
                            <th>Site</th>
                            <th>Farmer</th>
                            <th>Rakba</th>
                            <th>Area</th>
                            <th>Khasra</th>
                            <th>Payble amount</th>
                            <th>Paid Amount</th>
                            <th>Balance Amount</th>
                            <th>Payment Mode</th>
                            <th>Remark</th>
                            <th>Payment Date</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $lands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $land): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($land->site->name); ?></td>
                                <td><?php echo e($land->farmer->name); ?></td>
                                <td><?php echo e($land->rakba); ?></td>
                                <td><?php echo e($land->area); ?></td>
                                <td><?php echo e($land->khasra_numbers); ?></td>
                                <td><?php echo e($land->payble_amount); ?></td>
                                <td><?php echo e($land->paid_amount); ?></td>
                                <td><?php echo e($land->balance_amount); ?></td>
                                <td><?php echo e($land->payment_mode); ?></td>
                                <td><?php echo e($land->remark); ?></td>
                                <td><?php echo e($land->payment_date); ?></td>
                                <td>
                                    <a class="btn btn-primary" href="<?php echo e(route('land.edit', $land->id)); ?>">Edit</a>
                                    <button class="btn btn-danger">Lock</button>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
    <script src="<?php echo e(asset('assets/bundles/dataTables.bundle.js')); ?>"></script>
    <script>
        $(document).ready(function() {
            $('.my_data_table').addClass('nowrap').dataTable({
                responsive: true,
            });
        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layout.' . $layoutfor, \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Aryan\Desktop\realstate\realState\resources\views/pages/admin/land/list.blade.php ENDPATH**/ ?>