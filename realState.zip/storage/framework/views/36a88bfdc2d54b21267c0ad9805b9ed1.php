



<?php $__env->startSection('main_section'); ?>
    <div class="card mb-4">
        <div class="card-header">
            <h6 class="card-title mb-0">Create Farmer</h6>
        </div>
        <div class="card-body">
            <form class="row g-3 maskking-form" id="farmerForm" method="post" action="<?php echo e(route('farmer.store')); ?>">
                <?php echo csrf_field(); ?>
                <?php echo $__env->make('pages.admin.farmer.form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                <button type="submit" style="width: 100px" class="float-right btn btn-primary">Submit</button>

            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>


<?php $__env->startPush('scripts'); ?>
    <script src="<?php echo e(asset('assets/js/farmer-form-validator.js')); ?>"></script>
    <script>
        $("#country_select").change(function(e) {

            $.ajax({
                type: "get",
                url: "<?php echo e(route('getStates')); ?>",
                data: {
                    cId: e.target.value
                },

                success: function(response) {
                    $("#state_select").empty();
                    response.states.forEach(state => {
                        let option = `<option value= ${state.id} > ${state.name}</option>`
                        $("#state_select").append(option);
                    });
                }
            });

        });
    </script>
    <script>
        $("#state_select").change(function(e) {
            $.ajax({
                type: "get",
                url: "<?php echo e(route('getCities')); ?>",
                data: {
                    sId: e.target.value
                },

                success: function(response) {
                    $("#city_select").empty();
                    response.cities.forEach(city => {
                        let option = `<option value= ${city.id} > ${city.name}</option>`
                        $("#city_select").append(option);
                    });
                }
            });

        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layout.' . $layoutfor, \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Aryan\Desktop\realstate\realState\resources\views/pages/admin/farmer/create.blade.php ENDPATH**/ ?>