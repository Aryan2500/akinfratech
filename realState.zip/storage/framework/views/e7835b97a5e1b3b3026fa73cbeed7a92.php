 <header class="page-header sticky-top">
     <div class="container-fluid">
         <div class="d-flex justify-content-between align-items-center">
             <a class="me-4 d-lg-inline-flex d-none menu-toggle" href="#" title="Sidebar Toggle">
                 <svg width="24" viewBox="0 0 24 24" fill="currentColor" xmlns="http://www.w3.org/2000/svg">
                     <path fill="var(--accent-color)"
                         d="M14.7071 7.29289C15.0976 7.68342 15.0976 8.31658 14.7071 8.70711L12.4142 11H20C20.5523 11 21 11.4477 21 12C21 12.5523 20.5523 13 20 13H12.4142L14.7071 15.2929C15.0976 15.6834 15.0976 16.3166 14.7071 16.7071C14.3166 17.0976 13.6834 17.0976 13.2929 16.7071L9.29289 12.7071C8.90237 12.3166 8.90237 11.6834 9.29289 11.2929L13.2929 7.29289C13.6834 6.90237 14.3166 6.90237 14.7071 7.29289Z" />
                     <path fill="var(--accent-color)" fill-opacity="0.3"
                         d="M4 3C4.55228 3 5 3.44772 5 4V20C5 20.5523 4.55228 21 4 21C3.44772 21 3 20.5523 3 20V4C3 3.44772 3.44772 3 4 3Z" />
                 </svg>
             </a>
             <a class="me-4 d-lg-none d-inline-flex text-decoration-none text-accent align-items-center"
                 href="index.html">
                 <svg width="24" height="28" viewBox="0 0 24 28" fill="currentColor"
                     xmlns="http://www.w3.org/2000/svg">
                     <path class="fill-accent"
                         d="M10.123 17.0196H14.7278L17.0428 19.9893L19.3201 22.6346L23.6121 28H18.5568L15.6038 24.3815L14.0897 22.2353L10.123 17.0196ZM24 13.1266C24 15.9133 23.4703 18.284 22.4108 20.2389C21.3598 22.1937 19.9249 23.6869 18.1064 24.7184C16.2961 25.7415 14.2607 26.2531 12 26.2531C9.72263 26.2531 7.67883 25.7374 5.86861 24.7059C4.05839 23.6744 2.62774 22.1812 1.57664 20.2264C0.525548 18.2715 0 15.9049 0 13.1266C0 10.3399 0.525548 7.9691 1.57664 6.01426C2.62774 4.05942 4.05839 2.57041 5.86861 1.54724C7.67883 0.515746 9.72263 0 12 0C14.2607 0 16.2961 0.515746 18.1064 1.54724C19.9249 2.57041 21.3598 4.05942 22.4108 6.01426C23.4703 7.9691 24 10.3399 24 13.1266ZM18.5068 13.1266C18.5068 11.3215 18.2357 9.79917 17.6934 8.55972C17.1595 7.32026 16.4046 6.38028 15.4286 5.73975C14.4526 5.09923 13.3097 4.77897 12 4.77897C10.6903 4.77897 9.54745 5.09923 8.57143 5.73975C7.59541 6.38028 6.83629 7.32026 6.29406 8.55972C5.76017 9.79917 5.49322 11.3215 5.49322 13.1266C5.49322 14.9317 5.76017 16.454 6.29406 17.6934C6.83629 18.9329 7.59541 19.8728 8.57143 20.5134C9.54745 21.1539 10.6903 21.4742 12 21.4742C13.3097 21.4742 14.4526 21.1539 15.4286 20.5134C16.4046 19.8728 17.1595 18.9329 17.6934 17.6934C18.2357 16.454 18.5068 14.9317 18.5068 13.1266Z"
                         fill="#5BC43A" />
                 </svg>
                 <span class="fs-4 ps-2 d-none d-sm-inline-flex">Boat</span>
             </a>

             <ul class="header-menu flex-grow-1">
                 <?php if(!UserHelper::checkIfSiteHead()): ?>
                     <li class="w-100 d-none d-md-inline-flex">

                         <div class="row" style="width: 100%">

                             <select class="form-control form-control-md custom-select" id="top_select_site">
                                 <option value=""> Select Site </option>
                                 <?php $__currentLoopData = SiteHelper::getAllSites(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $site): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                     <option value="<?php echo e($site->id); ?>"><?php echo e($site->name); ?></option>
                                 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                             </select>

                         </div>

                     </li>
                 <?php endif; ?>


                 <li class="dropdown user">
                     <a class="dropdown-toggle text-decoration-none" href="#" role="button"
                         data-bs-toggle="dropdown" aria-expanded="false" title="User">
                         <img class="avatar sm rounded-circle shadow border border-2"
                             src="<?php echo e(asset('assets/img/profile_av.png')); ?>" alt="avatar">
                         <span class="ps-1 fs-6 text-white d-none d-lg-inline-block"><?php echo e(Auth::user()->name); ?></span>
                     </a>
                     <ul class="dropdown-menu dropdown-menu-end shadow border-0 p-4 rounded-4">
                         <li class="mb-3">
                             <a class="h5" href="crafted-profile.html" title=""><?php echo e(Auth::user()->name); ?></a>
                             <p><?php echo e(Auth::user()->email); ?></p>
                             <a class="btn bg-dark text-white w-100" href="<?php echo e(route('logout')); ?>"
                                 role="button">Logout</a>
                         </li>
                         <li class="dropdown-divider"></li>

                     </ul>
                 </li>
                 <li class="dropdown d-block d-lg-none">
                     <button class="btn btn-sm btn-white sidebar-toggle ms-3" type="button"><i
                             class="fa fa-bars"></i></button>
                 </li>
             </ul>
         </div>
     </div>
 </header>
 
<?php /**PATH C:\Users\Aryan\Desktop\realstate\realState\resources\views/partials/top-nav.blade.php ENDPATH**/ ?>