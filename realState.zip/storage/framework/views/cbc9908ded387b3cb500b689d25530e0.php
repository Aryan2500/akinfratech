


<?php $__env->startSection('page_css'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('assets/bundles/dataTables.min.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('main_section'); ?>
    <div class="row">
        <?php echo $__env->make('partials.alerts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div class="card mb-4">
            <div class="card-header">
                <h6 class="card-title mb-0">Plot's list</h6>
                <a type="button" href="<?php echo e(route('plot.create')); ?>" class="btn btn-outline-primary float-end ">Create plot</a>
            </div>
            <div class="card-body">
                <table class="my_data_table table display dataTable table-hover">
                    <thead>
                        <tr>
                            <th>Name</th>
                            <th>Address</th>
                            <th>Size</th>
                            <th>Site</th>
                            <th>Block</th>
                            <th>Status</th>
                            <th>Plot Type</th>
                            <th>Price</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $plots; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $plot): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($plot->name); ?></td>
                                <td><?php echo e($plot->address); ?></td>
                                <td><?php echo e($plot->size); ?> </td>
                                <td><?php echo e($plot->site->name); ?> </td>
                                <td><?php echo e($plot->block->name); ?> </td>

                                <td>
                                    <?php if($plot->isBooked): ?>
                                        <img src="<?php echo e(asset('imgs/booked.jpg')); ?>" width="80px" height="50px" />
                                    <?php else: ?>
                                        <img src="<?php echo e(asset('imgs/available.png')); ?>" width="50px" height="50px" />
                                    <?php endif; ?>
                                </td>


                                <td><?php echo e($plot->plotType ? $plot->plotType->name : 'N/A'); ?> </td>
                                <td><?php echo e($plot->price); ?> </td>

                                <td>
                                    <a class="btn btn-primary" href="<?php echo e(route('plot.edit', $plot->id)); ?>">Edit</a>

                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
    <script src="<?php echo e(asset('assets/bundles/dataTables.bundle.js')); ?>"></script>
    <script>
        $(document).ready(function() {
            $('.my_data_table').addClass('nowrap').dataTable({
                responsive: true,
            });
        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layout.' . $layoutfor, \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Aryan\Desktop\realstate\realState\resources\views/pages/admin/plot/list.blade.php ENDPATH**/ ?>