


<?php $__env->startSection('main_section'); ?>
    <?php echo $__env->make('partials.alerts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="card mb-4">
        <div class="card-header">
            <h6 class="card-title mb-0">Create Plot</h6>
        </div>

        <div class="card-body">
            <form class="row g-3 maskking-form" id="plotForm" method="post" action="<?php echo e(route('plot.store')); ?>">
                <?php echo $__env->make('pages.admin.plot.form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>


<?php $__env->startPush('scripts'); ?>
    <script src="<?php echo e(asset('assets/js/plot-form-validator.js')); ?>"></script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layout.' . $layoutfor, \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Aryan\Desktop\realstate\realState\resources\views/pages/admin/plot/create.blade.php ENDPATH**/ ?>