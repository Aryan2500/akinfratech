


<?php $__env->startSection('main_section'); ?>
    <div class="card mb-4">
        <div class="card-header">
            <h6 class="card-title mb-0">Create Land</h6>
        </div>
        <div class="card-body">
            <form class="row g-3 maskking-form" id="siteForm" method="post" action="<?php echo e(route('land.store')); ?>">
                <?php echo $__env->make('pages.admin.land.form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
    <script src="<?php echo e(asset('assets/js/site-form-validator.js')); ?>"></script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layout.' . $layoutfor, \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Aryan\Desktop\realstate\realState\resources\views/pages/admin/land/create.blade.php ENDPATH**/ ?>