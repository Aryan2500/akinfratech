<div class="page-title mb-lg-4">
    <div class="container-fluid">
        <ol class="breadcrumb bg-transparent w-100 li_animate mb-3 mb-md-1">
            <li class="breadcrumb-item"><a href="<?php echo e(route('dashboard')); ?>">Home</a></li>
            <li class="breadcrumb-item active" aria-current="page"><?php echo e($page_heading ? $page_heading : ''); ?></li>
        </ol>
        <h1 class="mb-0 text-gradient font-heading"><?php echo e($page_heading ? $page_heading : ''); ?></h1>

    </div>
</div>
<?php /**PATH C:\Users\Aryan\Desktop\realstate\realState\resources\views/partials/greeting.blade.php ENDPATH**/ ?>