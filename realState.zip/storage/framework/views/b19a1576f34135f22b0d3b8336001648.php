<div class="modal fade" id="plotModal" tabindex="-1" aria-labelledby="exampleModalXlLabel" style="display: none;"
    aria-hidden="true">
    <div class="modal-dialog modal-xl">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title h4" id="exampleModalXlLabel">Plots List</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <div class="card mb-4">
                    <div class="card-header">
                        <h6 class="card-title mb-0">Plot's list</h6>
                        <a type="button" href="<?php echo e(route('plot.create')); ?>"
                            class="btn btn-outline-primary float-end ">Create plot</a>
                    </div>
                    <div class="card-body">
                        <table class="my_data_table table display dataTable table-hover">
                            <thead>
                                <tr>
                                    <th>Name</th>
                                    <th>Address</th>
                                    <th>Size</th>
                                    <th>Site</th>
                                    <th>Status</th>
                                    <th>Plot Type</th>
                                    <th>Price</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = PlotHelper::getAllPlots(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $plot): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($plot->name); ?></td>
                                        <td><?php echo e($plot->address); ?></td>
                                        <td><?php echo e($plot->size); ?> </td>
                                        <td><?php echo e($plot->site->name); ?> </td>

                                        <td>
                                            <?php if($plot->isBooked): ?>
                                                <img src="<?php echo e(asset('imgs/booked.jpg')); ?>" width="80px"
                                                    height="50px" />
                                            <?php else: ?>
                                                <img src="<?php echo e(asset('imgs/available.png')); ?>" width="50px"
                                                    height="50px" />
                                            <?php endif; ?>
                                        </td>


                                        <td><?php echo e($plot->plotType ? $plot->plotType->name : 'N/A'); ?> </td>
                                        <td><?php echo e($plot->price); ?> </td>

                                        <td>
                                            <button class="btn btn-primary">Edit</button>
                                            <button class="btn btn-danger">Lock</button>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php /**PATH C:\Users\Aryan\Desktop\realstate\realState\resources\views/pages/admin/dashboard/plot-list-modal.blade.php ENDPATH**/ ?>