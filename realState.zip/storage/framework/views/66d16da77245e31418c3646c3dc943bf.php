

<?php $__env->startSection('page_css'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('assets/bundles/dataTables.min.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('main_section'); ?>
    <div class="row">
        <?php echo $__env->make('partials.alerts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div class="card mb-4">
            <div class="card-header">
                <h6 class="card-title mb-0">Users list</h6>
                <a type="button" href="<?php echo e(route('farmer.create')); ?>" class="btn btn-outline-primary float-end ">Create new</a>
            </div>
            <div class="card-body">
                <table class="my_data_table table display dataTable table-hover">
                    <thead>
                        <tr>
                            <th>Site</th>
                            <th>Farmer Name</th>
                            <th>State</th>
                            <th>City</th>
                            <th>Phone Number</th>
                            <th>Address</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $farmers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $f): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($f->sites->first()->name); ?></td>
                                <td><?php echo e($f->name); ?></td>
                                <td><?php echo e($f->city->state->name); ?></td>
                                <td><?php echo e($f->city->name); ?></td>
                                <td><?php echo e($f->phone); ?></td>
                                <td><?php echo e($f->address); ?></td>
                                <td>
                                    <a class="btn btn-primary" href="<?php echo e(route('farmer.edit', $f->id)); ?>">Edit</a>
                                    <button class="btn btn-danger">Lock</button>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                    </tbody>
                </table>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
    <script src="<?php echo e(asset('assets/bundles/dataTables.bundle.js')); ?>"></script>
    <script>
        $(document).ready(function() {
            $('.my_data_table').addClass('nowrap').dataTable({
                responsive: true,
            });
        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layout.' . $layoutfor, \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Aryan\Desktop\realstate\realState\resources\views/pages/admin/farmer/list.blade.php ENDPATH**/ ?>