


<?php $__env->startSection('page_css'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('assets/bundles/dataTables.min.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('main_section'); ?>
    <div class="row">
        <?php echo $__env->make('partials.alerts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div class="card mb-4">
            <div class="card-header">
                <h6 class="card-title mb-0"><?php echo e($page_heading); ?>s</h6>
                <a type="button" href="<?php echo e(route('block.create')); ?>" class="btn btn-outline-primary float-end ">Create
                    Block</a>
            </div>
            <div class="card-body">
                <table class="my_data_table table display dataTable table-hover">
                    <thead>
                        <tr>
                            <th>Name</th>
                            <th>Site</th>
                            <th>Size</th>
                            <th>Booked Area</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $blocks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $b): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($b->name); ?></td>
                                <td><?php echo e($b->site->name); ?></td>
                                <td><?php echo e($b->area); ?></td>
                                <td> <?php echo e($b->booked_area); ?> </td>
                                <td>
                                    <a href="<?php echo e(route('block.edit', $b->id)); ?>" class="btn btn-primary">Edit</a>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
    <script src="<?php echo e(asset('assets/bundles/dataTables.bundle.js')); ?>"></script>
    <script>
        $(document).ready(function() {
            $('.my_data_table').addClass('nowrap').dataTable({
                responsive: true,
            });
        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layout.' . $layoutfor, \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Aryan\Desktop\realstate\realState\resources\views/pages/admin/block/list.blade.php ENDPATH**/ ?>