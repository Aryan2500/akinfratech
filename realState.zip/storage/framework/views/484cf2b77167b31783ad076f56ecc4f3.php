

<?php $__env->startSection('main_section'); ?>
    <!--[ Start:: page body area ]-->

    <!--[ Start:: My Dashboard ]-->
    <div class="row g-3 row-deck">
        <div class="col-xxl-3 col-xl-6 col-lg-3 col-md-6 col-sm-12">
            <div class="card" data-bs-toggle="modal" data-bs-target="#userModal" style="cursor: pointer">
                <div class="card-body">
                    <h3><?php echo e($users); ?> </h3>
                    <p class="text-muted"> <i class="fa fa-users text-success"></i> Total Users</p>
                    <div id="apexspark_bar_1"></div>
                </div>
            </div>
        </div>
        <div class="col-xxl-3 col-xl-6 col-lg-3 col-md-6 col-sm-12">
            <div class="card" data-bs-toggle="modal" data-bs-target="#siteModal" style="cursor: pointer">
                <div class="card-body">
                    <h3><?php echo e($sites); ?> </h3>
                    <p class="text-muted"><i class="fa fa-building text-success"></i> Total Sites
                    </p>
                    <div id="apexspark_bar_2"></div>
                </div>
            </div>
        </div>
        <div class="col-xxl-3 col-xl-6 col-lg-3 col-md-6 col-sm-12">
            <div class="card" data-bs-toggle="modal" data-bs-target="#plotModal" style="cursor: pointer">
                <div class="card-body">
                    <h3><?php echo e($plots); ?> </h3>
                    <p class="text-muted"><i class="fa fa-building text-success"></i> Total Plots</p>
                    <div id="apexspark_bar_3"></div>
                </div>
            </div>
        </div>
        <div class="col-xxl-3 col-xl-6 col-lg-3 col-md-6 col-sm-12">
            <div class="card" data-bs-toggle="modal" data-bs-target="#farmerModal" style="cursor: pointer">
                <div class="card-body">
                    <h3><?php echo e($farmers); ?> </h3>
                    <p class="text-muted"><i class="fa fa-building text-success"></i> Total Farmer</p>
                    <div id="apexspark_bar_3"></div>
                </div>
            </div>
        </div>
        

        <?php echo $__env->make('pages.admin.dashboard.farmer-list-modal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->make('pages.admin.dashboard.site-list-modal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->make('pages.admin.dashboard.plot-list-modal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->make('pages.admin.dashboard.user-list-modal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
    <div class="row row-deck-site-wise" style="display:none">
        
        <div class="col-xxl-3 col-xl-6 col-lg-3 col-md-6 col-sm-12">
            <div class="card" data-bs-toggle="modal" data-bs-target="#plotModal" style="cursor: pointer">
                <div class="card-body">
                    <h3 id="numberOfPlots"><?php echo e($plots); ?> </h3>
                    <p class="text-muted"><i class="fa fa-building text-success"></i> Plots</p>
                    <div id="apexspark_bar_3"></div>
                </div>
            </div>
        </div>
        <div class="col-xxl-3 col-xl-6 col-lg-3 col-md-6 col-sm-12">
            <div class="card" data-bs-toggle="modal" data-bs-target="#farmerModal" style="cursor: pointer">
                <div class="card-body">
                    <h3 id="NumberOffarmer"><?php echo e($farmers); ?> </h3>
                    <p class="text-muted"><i class="fa fa-building text-success"></i> Farmer</p>
                    <div id="apexspark_bar_3"></div>
                </div>
            </div>
        </div>
    </div>

    <div id="chartContainer" style="margin-top: 50px;height: 300px; width: 50%;"></div>

    
<?php $__env->stopSection(); ?>


<?php $__env->startPush('scripts'); ?>
    <script>
        $(document).ready(function() {
            $("#top_select_site").change(function(e) {
                getdata(e.target.value);
                $('.row-deck').fadeOut();
            });
        });

        function getdata($siteId) {
            $.ajax({
                type: "get",
                url: "<?php echo e(route('dashboardInfo')); ?>",
                data: {
                    'site_id': $siteId
                },
                success: function(res) {
                    console.log(res);
                    $("#numberOfPlots").text(res.plots);
                    $("#NumberOffarmer").text(res.farmers);
                    setTimeout(() => {
                        $('.row-deck-site-wise').fadeIn();
                    }, 500);

                }
            });
        }
    </script>
<?php $__env->stopPush(); ?>

<?php $__env->startPush('scripts'); ?>
    <script type="text/javascript">
        window.onload = function() {
            var options = {
                title: {
                    text: "Land"
                },
                data: [{
                    type: "pie",
                    startAngle: 45,
                    showInLegend: "true",
                    legendText: "{label}",
                    indexLabel: "{label} ({y})",
                    yValueFormatString: "#,##0.#" % "",
                    dataPoints: [{
                            label: "Available",
                            y: 1000
                        },
                        {
                            label: "Booked",
                            y: 31
                        },
                        // {
                        //     label: "Referrals",
                        //     y: 7
                        // },
                        // {
                        //     label: "Twitter",
                        //     y: 7
                        // },
                        // {
                        //     label: "Facebook",
                        //     y: 6
                        // },
                        // {
                        //     label: "Google",
                        //     y: 10
                        // },
                        // {
                        //     label: "Others",
                        //     y: 3
                        // }
                    ]
                }]
            };
            $("#chartContainer").CanvasJSChart(options);

        }
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layout.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Aryan\Desktop\realstate\realState\resources\views/pages/admin/dashboard.blade.php ENDPATH**/ ?>