<div>
    <?php echo csrf_field(); ?>
    <input type="hidden" name="id" value="<?php echo e($plot ? $plot->id : ''); ?>">
    <div class="row">
        <div class="col-6">
            <span class="float-label mt-2">
                <input type="text" class="form-control form-control-lg" id="TextInput" name="name" placeholder="Name"
                    value="<?php echo e($plot ? $plot->name : ''); ?>" required>
                <label class="form-label" for="TextInput">Name</label>
            </span>
        </div>
        <div class="col-6 mt-2">
            <span class="float-label">
                <input type="text" class="form-control form-control-lg" id="TextInput" name="size" required
                    value="<?php echo e($plot ? $plot->size : ''); ?>" placeholder="Size">
                <label class="form-label" for="TextInput">Size</label>
            </span>
        </div>
        <div class="col-6 mt-2">
            <span class="float-label">
                <input type="text" class="form-control form-control-lg" id="TextInput" name="address" required
                    value="<?php echo e($plot ? $plot->address : ''); ?>" placeholder="Address">
                <label class="form-label" for="TextInput">Address</label>
            </span>
        </div>
        <div class="col-6 mt-2">
            <span class="float-label">
                <input type="text" class="form-control form-control-lg" id="TextInput" name="price" required
                    placeholder="Price" value="<?php echo e($plot ? $plot->price : ''); ?>">
                <label class="form-label" for="TextInput">Price</label>
            </span>
        </div>
        <div class="col-6 mt-2">
            <label class="form-group float-label">
                <select class="form-control form-control-lg custom-select" name="site_id" required>
                    <option value="">Choose Site </option>
                    <?php $__currentLoopData = SiteHelper::getAllSites(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $site): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($site->id); ?>"
                            <?php echo e($plot ? ($plot->site_id == $site->id ? 'selected' : '') : ''); ?>>
                            <?php echo e($site->name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <span>Site</span>
            </label>
        </div>
        <div class="col-6 mt-2">
            <label class="form-group float-label">
                <select class="form-control form-control-lg custom-select" name="block_id" required>
                    <option value="">Choose Block </option>
                    <?php $__currentLoopData = $blocks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $b): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($b->id); ?>"
                            <?php echo e($plot ? ($plot->block_id == $b->id ? 'selected' : '') : ''); ?>>
                            <?php echo e($b->name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <span>Block</span>
            </label>
        </div>
        <div class="col-6 mt-2">
            <label class="form-group float-label">
                <select class="form-control form-control-lg custom-select" name="plottype_id" required>
                    <option value="">Choose Plot type </option>
                    <?php $__currentLoopData = PlotHelper::getAllPlotTypes(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ptype): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($ptype->id); ?>"
                            <?php echo e($plot ? ($plot->plottype_id == $ptype->id ? 'selected' : '') : ''); ?>>
                            <?php echo e($ptype->name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <span>Plot type</span>
            </label>
        </div>
    </div>

    <div class="col-2">
        <button type="submit" class=" btn btn-primary">Submit</button>
    </div>
</div>
<?php /**PATH C:\Users\Aryan\Desktop\realstate\realState\resources\views/pages/admin/plot/form.blade.php ENDPATH**/ ?>