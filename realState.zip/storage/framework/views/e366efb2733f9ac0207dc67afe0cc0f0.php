<div class="row " id="inputParent">
    

    <input type="hidden" name="id" value="<?php echo e($farmer ? $farmer->id : ''); ?>">

    <div class="col-lg-3 col-md-6">
        <label class="form-label">Select Site</label>
        <select class="form-control show-tick   select2" multiple data-placeholder="Select" required name="site_id[]">
            <option id="" value="">--Select--</option>


            <?php $__currentLoopData = SiteHelper::getAllSites(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($s->id); ?>"
                    <?php if($farmer): ?> <?php $__currentLoopData = $farmer->sites; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $site): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php echo e($site->id == $s->id ? ' selected="selected"' : ''); ?> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> <?php endif; ?>>
                    <?php echo e($s->name); ?>

                </option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
    </div>
    <div class="col-lg-3 col-md-6">
        <label class="form-label">Select Country</label>
        <select class="form-control show-tick   select2" required data-placeholder="Select" name="country_id"
            id="country_select">
            <option id="" value="">--Select--</option>
            <?php $__currentLoopData = LocationHelper::getCountries(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($c->id); ?>"
                    <?php echo e($farmer ? ($farmer->country_id == $c->id ? 'selected' : '') : ''); ?>><?php echo e($c->name); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
    </div>
    <div class="col-lg-3 col-md-6">
        <label class="form-label">Select State</label>
        <select class="form-control show-tick   select2" required data-placeholder="Select" name="state_id"
            id="state_select">
            <option id="" value="">--Select--</option>

        </select>
    </div>
    <div class="col-lg-3 col-md-6">
        <label class="form-label">Select City</label>
        <select class="form-control show-tick   select2" required data-placeholder="Select" name="city_id"
            id="city_select">
            <option id="" value="">--Select--</option>

        </select>
    </div>


    <div class="col-6 mt-3">
        <span class="float-label">
            <input type="text" class="form-control form-control-lg" required id="TextInput" name="name"
                placeholder="Name" value="<?php echo e($farmer ? $farmer->name : ''); ?>">
            <label class="form-label" for="TextInput">Name</label>
        </span>
    </div>

    <div class="col-6 mt-3">
        <span class="float-label">
            <input type="text" class="form-control form-control-lg" id="TextInput" name="phone" required
                placeholder="Phone Number" value="<?php echo e($farmer ? $farmer->phone : ''); ?>">
            <label class="form-label" for="TextInput">Phone Number</label>
        </span>
    </div>
    <div class="col-6 mt-3">
        <span class="float-label">
            <textarea class="form-control form-control-lg" id="TextInput" required name="address" id=""><?php echo e($farmer ? $farmer->address : ''); ?></textarea>
            <label class="form-label" for="TextInput">Address</label>
        </span>
    </div>

</div>
<?php /**PATH C:\Users\Aryan\Desktop\realstate\realState\resources\views/pages/admin/farmer/form.blade.php ENDPATH**/ ?>