<div>
    <?php echo csrf_field(); ?>
    <input type="hidden" name="id" value="<?php echo e($land ? $land->id : ''); ?>">
    <div class="row">
        <div class="col-6 ">
            <label class="form-group float-label">
                <select class="form-control form-control-lg custom-select" name="site_id" required>
                    <option value="">Choose Site</option>
                    <?php $__currentLoopData = SiteHelper::getAllSites(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $site): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($site->id); ?>"
                            <?php echo e($land ? ($land->site_id == $site->id ? 'selected' : '') : ''); ?>><?php echo e($site->name); ?>

                        </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <span>SItes</span>
            </label>
        </div>

        <div class="col-6">
            <label class="form-group float-label">
                <select class="form-control form-control-lg custom-select" name="farmer_id" required>
                    <option value="">Choose Farmer</option>
                    <?php $__currentLoopData = FarmerHelper::getAllFarmers(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $farmer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($farmer->id); ?>"
                            <?php echo e($land ? ($land->farmer_id == $farmer->id ? 'selected' : '') : ''); ?>><?php echo e($farmer->name); ?>

                        </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <span>Farmer</span>
            </label>
        </div>

        <div class="col-6">
            <span class="float-label mt-3">
                <input type="text" class="form-control form-control-lg" name="area" placeholder="Name"
                    value="<?php echo e($land ? $land->area : ''); ?>" required>
                <label class="form-label" for="TextInput">Area</label>
            </span>
        </div>
        <div class="col-6">
            <span class="float-label mt-3">
                <input type="text" class="form-control form-control-lg" name="khasra_number" placeholder="Name"
                    value="<?php echo e($land ? $land->khasra_numbers : ''); ?>" required>
                <label class="form-label" for="TextInput">Khasra Number</label>
            </span>
        </div>
        <div class="col-6">
            <span class="float-label mt-3">
                <input type="text" class="form-control form-control-lg" name="rakba" placeholder="Name"
                    value="<?php echo e($land ? $land->rakba : ''); ?>">
                <label class="form-label" for="TextInput">Rakba</label>
            </span>
        </div>
        <div class="col-6">
            <span class="float-label mt-3">
                <input type="text" class="form-control form-control-lg" name="payble_amount" placeholder="Name"
                    value="<?php echo e($land ? $land->payble_amount : ''); ?>" required>
                <label class="form-label" for="TextInput">Payble Amount</label>
            </span>
        </div>
        <div class="col-6 mt-3">
            <label class="form-group float-label">
                <select class="form-control form-control-lg custom-select" name="payment_mode" required>
                    <option value="">Choose Payment Mode</option>
                    <?php $__currentLoopData = PAYMENT_MODE; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pm): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($pm); ?>"
                            <?php echo e($land ? ($land->payment_mode == $pm ? 'selected' : '') : ''); ?>>
                            <?php echo e($pm); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <span>Payment Mode</span>
            </label>
        </div>
        <div class="col-6 mt-3">
            <label class="form-group float-label">
                <select class="form-control form-control-lg custom-select" name="registry_status" required>
                    <option value=1 <?php echo e($land ? $land->registry_status == 1 : 'selected'); ?>>Yes</option>
                    <option value=0 <?php echo e($land ? $land->registry_status == 0 : 'selected'); ?>>NO</option>
                </select>
                <span>Registry Status</span>
            </label>
        </div>

        <div class="col-6">
            <span class="float-label mt-3">
                <input type="text" class="form-control form-control-lg" name="paid_amount" placeholder="Name"
                    required value="<?php echo e($land ? $land->paid_amount : ''); ?>">
                <label class="form-label" for="TextInput">Paid Amount</label>
            </span>
        </div>
        <div class="col-6">
            <span class="float-label mt-3">
                <input type="text" class="form-control form-control-lg" name="balance_amount" placeholder="Name"
                    required value="<?php echo e($land ? $land->balance_amount : ''); ?>">
                <label class="form-label" for="TextInput">Balance Amount</label>
            </span>
        </div>
        <div class="col-6">
            <span class="float-label mt-3">
                <input type="date" class="form-control form-control-lg" name="payment_date" placeholder="Name"
                    required value="<?php echo e($land ? $land->payment_date : ''); ?>">
                <label class="form-label" for="TextInput">Payment Date</label>
            </span>
        </div>
        <div class="col-6">
            <span class="float-label mt-3">
                <input type="text" class="form-control form-control-lg" name="total_size" placeholder="Total Size"
                    required value="<?php echo e($land ? $land->total_size : ''); ?>">
                <label class="form-label" for="TextInput">Total Size</label>
            </span>
        </div>
        <div class="col-6">
            <span class="float-label mt-3">
                <textarea name="remark" id="" placeholder="Remark" class="form-control form-control-lg" required></textarea>
                <label class="form-label" for="TextInput">Remark</label>
            </span>
        </div>

    </div>

    <div class="col-2">
        <button type="submit" class=" btn btn-primary">Submit</button>
    </div>
</div>
<?php /**PATH C:\Users\Aryan\Desktop\realstate\realState\resources\views/pages/admin/land/form.blade.php ENDPATH**/ ?>