<div class="modal fade" id="siteModal" tabindex="-1" aria-labelledby="exampleModalXlLabel" style="display: none;"
    aria-hidden="true">
    <div class="modal-dialog modal-xl">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title h4" id="exampleModalXlLabel">Site List</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <div class="card-header">
                    <h6 class="card-title mb-0">Site list</h6>
                    <a type="button" href="<?php echo e(route('site.create')); ?>"
                        class="btn btn-outline-primary float-end ">Create site</a>
                </div>
                <div class="card-body">
                    <table class="my_data_table table display dataTable table-hover">
                        <thead>
                            <tr>
                                <th>Name</th>
                                <th>Address</th>
                                <th>Site Head</th>
                                <th>Investors</th>
                                <th>Total size</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = SiteHelper::getAllSites(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $site): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($site->name); ?></td>
                                    <td><?php echo e($site->address); ?></td>

                                    <td>
                                        <?php if($site->head): ?>
                                            <?php echo e($site->head ? $site->head->name : ''); ?> <br>
                                            <?php echo e($site->head ? $site->head->email : ''); ?> <br>
                                            <?php echo e($site->head ? $site->head->phone : ''); ?>

                                        <?php else: ?>
                                            <?php echo e('N/A'); ?>

                                        <?php endif; ?>

                                    </td>
                                    <td>
                                        <?php if(count($site->investors) > 0): ?>
                                            <ul>
                                                <?php $__currentLoopData = $site->investors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $investor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <li><?php echo e($investor->name); ?></li>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </ul>
                                        <?php else: ?>
                                            <?php echo e('N/A'); ?>

                                        <?php endif; ?>
                                    </td>
                                    <td><?php echo e($site->total_size); ?></td>
                                    <td>
                                        <button class="btn btn-primary">Edit</button>
                                        <button class="btn btn-danger">Lock</button>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
<?php /**PATH C:\Users\Aryan\Desktop\realstate\realState\resources\views/pages/admin/dashboard/site-list-modal.blade.php ENDPATH**/ ?>