 <!--[ Start:: page footer link copywrite ]-->
 <footer class="page-footer py-4 mt-4 ">
    <div class="container-fluid">
        <p class="col-md-4 mb-0 text-muted">© 2023 <a href=" " target="_blank"
                title="Pixelwibes">{{env('APP_NAME')}}</a>, All Rights Reserved.</p>
    </div>
</footer>