<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class InvestorsController extends Controller
{
    //
}
