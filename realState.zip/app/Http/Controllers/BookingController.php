<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class BookingController extends Controller
{
    //

    function index()
    {
    }
    function create()
    {
    }
    function store()
    {
    }
    function edit($id)
    {
    }
    function update()
    {
    }
}
